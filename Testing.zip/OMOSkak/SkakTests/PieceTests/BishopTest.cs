﻿using OMOSkakServer;

namespace SkakTests.PieceTests
{
    [TestClass]
    public class BishopTest
    {
        private Board board;

        [TestInitialize]
        public void Initialize()
        {
            board = new Board();
        }
        [TestMethod]
        public void SpawnBishop()
        {
            string err;
            //Act
            board.SpawnPieceOnSpace("a1", BishopPiece.Instance, 1, out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("a1", out err);
            Assert.AreEqual('♗', board.grid[coord.Item1, coord.Item2].GetDisplayChar());
            Assert.AreEqual('B', board.grid[coord.Item1, coord.Item2].GetDisplayLetter());
        }
        [TestMethod]
        public void TestMovement()
        {
            //Arrange
            string moveFrom = "c1";
            string moveTo = "g5";
            Piece piece = board.SpawnPieceOnSpace(moveFrom, BishopPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece(moveFrom, moveTo, out _);
            //Assert
            Assert.IsTrue(result);
            Tuple<int, int> coord = board.GetCoordFromString(moveTo, out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestIllegalMovemet()
        {
            //Arrange
            string moveFrom = "c1";
            string moveTo = "c5";
            Piece piece = board.SpawnPieceOnSpace(moveFrom, BishopPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece(moveFrom, moveTo, out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString(moveFrom, out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
    }
}