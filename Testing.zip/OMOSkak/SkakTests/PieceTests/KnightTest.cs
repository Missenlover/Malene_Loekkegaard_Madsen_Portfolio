﻿using OMOSkakServer;

namespace SkakTests.PieceTests
{
    [TestClass]
    public class KnightTest
    {
        private Board board;
        [TestInitialize]
        public void Initialize()
        {
            board = new Board();
        }
        [TestMethod]
        public void SpawnKnight()
        {
            string err;
            //Act
            board.SpawnPieceOnSpace("a1", KnightPiece.Instance, 1, out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("a1", out err);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2].GetDisplayChar(), '♘');
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2].GetDisplayLetter(), 'N');
        }
        [TestMethod]
        public void TestLegalMove2V1H()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            //Act
            board.MovePiece("b1", "c3", out _);
            //Assert
            Tuple<int,int> coord = board.GetCoordFromString("c3", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestLegalMove1V2H()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            //Act
            board.MovePiece("b1", "d2", out _);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d2", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestLegalMove2V1HOverPiece()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            board.SpawnPieceOnSpace("b2", KnightPiece.Instance, 1, out _);
            board.SpawnPieceOnSpace("c2", KnightPiece.Instance, 1, out _);

            //Act
            board.MovePiece("b1", "c3", out _);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("c3", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestLegalMove1V2HOverPiece()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            board.SpawnPieceOnSpace("c1", KnightPiece.Instance, 1, out _);
            board.SpawnPieceOnSpace("c2", KnightPiece.Instance, 1, out _);

            //Act
            board.MovePiece("b1", "d2", out _);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d2", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestInvalidMove()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece("b1", "d3", out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("b1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
            coord = board.GetCoordFromString("d3", out _);
            Assert.IsNull(board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestCapture2V1H()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            board.SpawnPieceOnSpace("c3", KnightPiece.Instance, 2, out _);

            //Act
            board.MovePiece("b1", "c3", out _);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("c3", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestCapture1V2H()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            board.SpawnPieceOnSpace("d2", KnightPiece.Instance, 2, out _);

            //Act
            board.MovePiece("b1", "d2", out _);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d2", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestInvalidCapture2V1H()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            Piece piece2 = board.SpawnPieceOnSpace("c3", KnightPiece.Instance, 1, out _);

            //Act
            bool result = board.MovePiece("b1", "c3", out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("b1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
            coord = board.GetCoordFromString("c3", out _);
            Assert.AreEqual(piece2, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestInvalidCapture1V2H()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("b1", KnightPiece.Instance, 1, out _);
            Piece piece2 = board.SpawnPieceOnSpace("d2", KnightPiece.Instance, 1, out _);

            //Act
            bool result = board.MovePiece("b1", "d2", out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("b1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
            coord = board.GetCoordFromString("d2", out _);
            Assert.AreEqual(piece2, board.grid[coord.Item1, coord.Item2]);
        }
    }
}