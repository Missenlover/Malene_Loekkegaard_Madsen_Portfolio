namespace SkakTests.PieceTests
{
    [TestClass]
    public class QueenTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}