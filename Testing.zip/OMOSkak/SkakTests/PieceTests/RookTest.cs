﻿using OMOSkakServer;

namespace SkakTests.PieceTests
{
    [TestClass]
    public class RookTest
    {
        private Board board;
        [TestInitialize]
        public void Initialize()
        {
            board = new Board();
        }
        [TestMethod]
        public void SpawnRook()
        {
            string err;
            //Act
            board.SpawnPieceOnSpace("a1", RookPiece.Instance, 1, out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("a1", out err);
            Assert.AreEqual('♖', board.grid[coord.Item1, coord.Item2].GetDisplayChar());
            Assert.AreEqual('R', board.grid[coord.Item1, coord.Item2].GetDisplayLetter());
        }
        [TestMethod]
        public void TestLegalMoveHorizontal()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("a1", RookPiece.Instance, 1, out _);
            //Act
            board.MovePiece("a1", "h1", out _);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("h1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestLegalMoveVerticalPos()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("a1", RookPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece("a1", "a8", out _);
            //Assert
            Assert.IsTrue(result);
            Tuple<int, int> coord = board.GetCoordFromString("a8", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestLegalMoveVerticalNeg()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("h8", RookPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece("h8", "h1", out _);
            //Assert
            Assert.IsTrue(result);
            Tuple<int, int> coord = board.GetCoordFromString("h1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestIllegalMoveDiagonal()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("a1", RookPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece("a1", "h8", out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("a1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestIllegalMoveHorizontalBlockedPos()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("a1", RookPiece.Instance, 1, out _);
            Piece p2 = board.SpawnPieceOnSpace("b1", RookPiece.Instance, 1, out _);
            //Act
            bool result =  board.MovePiece("a1", "h1", out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("a1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestIllegalMoveHorizontalBlockedNeg()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("h1", RookPiece.Instance, 1, out _);
            Piece p2 = board.SpawnPieceOnSpace("g1", RookPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece("h1", "a1", out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("h1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestIllegalMoveVerticalBlockedPos()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("a1", RookPiece.Instance, 1, out _);
            Piece p2 = board.SpawnPieceOnSpace("a7", RookPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece("a1", "a8", out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("a1", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestIllegalMoveVerticalBlockedNeg()
        {
            //Arrange
            Piece piece = board.SpawnPieceOnSpace("h8", RookPiece.Instance, 1, out _);
            Piece p2 = board.SpawnPieceOnSpace("h2", RookPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece("h8", "h1", out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("h8", out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestIllegalMoveOnAllyVert()
        {
            //Arrange
            string moveFrom = "a1";
            string moveTo = "a2";
            Piece piece = board.SpawnPieceOnSpace(moveFrom, RookPiece.Instance, 1, out _);
            Piece piece2 = board.SpawnPieceOnSpace(moveTo, RookPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece(moveFrom, moveTo, out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString(moveFrom, out _);
            Assert.AreEqual(piece, board.grid[coord.Item1,coord.Item2]);
        }
        [TestMethod]
        public void TestIllegalMoveOnAllyHoriz()
        {
            //Arrange
            string moveFrom = "a1";
            string moveTo = "h1";
            Piece piece = board.SpawnPieceOnSpace(moveFrom, RookPiece.Instance, 1, out _);
            Piece piece2 = board.SpawnPieceOnSpace(moveTo, RookPiece.Instance, 1, out _);
            //Act
            bool result = board.MovePiece(moveFrom, moveTo, out _);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString(moveFrom, out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestCaptureVert()
        {
            //Arrange
            string moveFrom = "a1";
            string moveTo = "a8";
            Piece piece = board.SpawnPieceOnSpace(moveFrom, RookPiece.Instance, 1, out _);
            Piece piece2 = board.SpawnPieceOnSpace(moveTo, RookPiece.Instance, 2, out _);
            //Act
            bool result = board.MovePiece(moveFrom, moveTo, out _);
            //Assert
            Assert.IsTrue(result);
            Tuple<int, int> coord = board.GetCoordFromString(moveTo, out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod]
        public void TestCaptureHoriz()
        {
            //Arrange
            string moveFrom = "a1";
            string moveTo = "h1";
            Piece piece = board.SpawnPieceOnSpace(moveFrom, RookPiece.Instance, 1, out _);
            Piece piece2 = board.SpawnPieceOnSpace(moveTo, RookPiece.Instance, 2, out _);
            //Act
            bool result = board.MovePiece(moveFrom, moveTo, out _);
            //Assert
            Assert.IsTrue(result);
            Tuple<int, int> coord = board.GetCoordFromString(moveTo, out _);
            Assert.AreEqual(piece, board.grid[coord.Item1, coord.Item2]);
        }
    }
}