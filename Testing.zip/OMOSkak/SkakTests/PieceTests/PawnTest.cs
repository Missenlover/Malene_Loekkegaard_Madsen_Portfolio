﻿using OMOSkakServer;
using OMOSkak;
namespace SkakTests.PieceTests
{
    [TestClass]
    public class PawnTest
    {
        private Board board;
        [TestInitialize]
        public void Initialize()
        {
            board = new Board();
        }
        [TestMethod]
        public void SpawnPawn()
        {
            string err;
            //Act
            board.SpawnPieceOnSpace("a1", PawnPiece.Instance, 1, out err);
            //Assert
            Tuple<int,int> coord = board.GetCoordFromString("a1", out err);
            Assert.AreEqual(board.grid[coord.Item1,coord.Item2].GetDisplayChar(), '♙');
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2].GetDisplayLetter(), 'P');
        }
        [TestMethod]
        public void TestLegalMove1ForwardP1()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out err);
            //Act
            bool result = board.MovePiece("d2", "d3", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d3", out err);
            Assert.IsTrue(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2],piece);
        }
        [TestMethod]
        public void TestLegalMove1ForwardP2()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d7", PawnPiece.Instance, 2, out err);
            //Act
            bool result = board.MovePiece("d7", "d6", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d6", out err);
            Assert.IsTrue(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestLegalMove2ForwardP1()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out err);
            //Act
            bool result = board.MovePiece("d2", "d4", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d4", out err);
            Assert.IsTrue(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }

        [TestMethod]
        public void TestLegalMove2ForwardP2()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d7", PawnPiece.Instance, 2, out err);
            //Act
            bool result = board.MovePiece("d7", "d5", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d5", out err);
            Assert.IsTrue(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestIllegalMove2ForwardP1NonFirst()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out err);
            //Act
            board.MovePiece("d2", "d3", out err);
            bool result = board.MovePiece("d3", "d5", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d3", out err);
            Assert.IsFalse(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }

        [TestMethod]
        public void TestIllegalMove2ForwardP2NonFirst()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d7", PawnPiece.Instance, 2, out err);
            //Act
            board.MovePiece("d7", "d6", out err);
            bool result = board.MovePiece("d6", "d4", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d6", out err);
            Assert.IsFalse(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestIllegalMove1BackwardP1()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out err);
            //Act
            bool result = board.MovePiece("d2", "d1", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d2", out err);
            Assert.IsFalse(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }

        [TestMethod]
        public void TestIllegalMove1BackwardP2()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d7", PawnPiece.Instance, 2, out err);
            //Act
            bool result = board.MovePiece("d7", "d8", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d7", out err);
            Assert.IsFalse(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestIllegalMove1SidewaysP1()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out err);
            //Act
            bool result = board.MovePiece("d2", "e2", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d2", out err);
            Assert.IsFalse(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }

        [TestMethod]
        public void TestIllegalMove1SidewaysP2()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d7", PawnPiece.Instance, 2, out err);
            //Act
            bool result = board.MovePiece("d7", "e7", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d7", out err);
            Assert.IsFalse(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestLegalCaptureP1()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out err);
            board.SpawnPieceOnSpace("e3", PawnPiece.Instance, 2, out err);
            //Act
            bool result = board.MovePiece("d2", "e3", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("e3", out err);
            Assert.IsTrue(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestLegalCaptureP2()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d7", PawnPiece.Instance, 2, out err);
            board.SpawnPieceOnSpace("e6", PawnPiece.Instance, 1, out err);
            //Act
            bool result = board.MovePiece("d7", "e6", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("e6", out err);
            Assert.IsTrue(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestIllegalCaptureP1NoTarget()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out err);
            //Act
            bool result = board.MovePiece("d2", "e3", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d2", out err);
            Assert.IsFalse(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestIllegalCaptureP2NoTarget()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d7", PawnPiece.Instance, 2, out err);
            //Act
            bool result = board.MovePiece("d7", "e6", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("d7", out err);
            Assert.IsFalse(result);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
        }
        [TestMethod]
        public void TestIllegalCaptureP1AlliedPiece()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out err);
            Piece piece2 = board.SpawnPieceOnSpace("e3", PawnPiece.Instance, 1, out err);
            //Act
            bool result = board.MovePiece("d2", "e3", out err);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("d2", out err);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
            Tuple<int, int> coord2 = board.GetCoordFromString("e3", out err);
            Assert.AreEqual(board.grid[coord2.Item1, coord2.Item2], piece2);
        }
        [TestMethod]
        public void TestIllegalCaptureP2AlliedPiece()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("d7", PawnPiece.Instance, 2, out err);
            Piece piece2 = board.SpawnPieceOnSpace("e6", PawnPiece.Instance, 2, out err);
            //Act
            bool result = board.MovePiece("d7", "e6", out err);
            //Assert
            Assert.IsFalse(result);
            Tuple<int, int> coord = board.GetCoordFromString("d7", out err);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
            Tuple<int, int> coord2 = board.GetCoordFromString("e6", out err);
            Assert.AreEqual(board.grid[coord2.Item1, coord2.Item2], piece2);
        }
    }
}