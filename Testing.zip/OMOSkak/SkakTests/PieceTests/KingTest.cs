namespace SkakTests.PieceTests
{
    [TestClass]
    public class KingTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}