﻿using OMOClient;
using OMOSkak;
using System.Net;
using System.Net.Sockets;
namespace SkakTests.OtherTests
{
    [TestClass]
    public class ServerTest
    {
        private TcpListener server;
        private Thread serverThread;
        private int port = 13000;
        private IPAddress localAddr = IPAddress.Parse("127.0.0.1");

        [TestInitialize]
        public void Initialize()
        {
            server = new TcpListener(localAddr, port);
            serverThread = new Thread(() => server.Start());
            serverThread.Start();
        }

        [TestCleanup]
        public void Cleanup()
        {
            server.Stop();
        }
        

        [TestMethod]
        public void Server_AcceptClient()
        {
            //Arrange
            TcpClient client = new TcpClient();
            //Act
            client.Connect(localAddr, port);
            //Assert
            Assert.IsTrue(client.Connected);
        }

        [TestMethod]
        public void Server_Start()
        {
            //Arrange is performed in Initialize
            //Act is performed in Initialize
            //Assert
            //IsBound
            Assert.IsTrue(true);
        }

        [TestMethod]
        public void Server_TestChatClientConnection()
        {
            ChessClient chessClient = new ChessClient();
            chessClient.testing = true;

            chessClient.ConnectClient();

            Assert.IsTrue(chessClient.client.Connected);
        }
    }
}
