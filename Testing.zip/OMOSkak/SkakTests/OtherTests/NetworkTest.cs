namespace SkakTests.OtherTests
{
    [TestClass]
    public class NetworkTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}