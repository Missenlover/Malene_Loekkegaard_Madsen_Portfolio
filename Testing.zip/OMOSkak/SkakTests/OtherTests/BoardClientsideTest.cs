namespace SkakTests.OtherTests
{
    [TestClass]
    public class BoardClientsideTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}