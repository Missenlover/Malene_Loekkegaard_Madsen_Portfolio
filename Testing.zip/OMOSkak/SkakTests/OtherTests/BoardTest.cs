using OMOSkak;
using OMOSkakServer;
using System.Security.AccessControl;
namespace SkakTests.OtherTests
{
    [TestClass]
    public class BoardTest
    {
        private Board board;
        [TestInitialize]
        public void Initialize()
        {
            board = new Board();
        }
        [TestMethod]
        public void SpawnPieceOnSpace()
        {
            //Act
            board.SpawnPieceOnSpace("a1", TestPieceTypeBase.Instance, 1, out _);

            //Assert
            Assert.AreEqual(board.grid[0,7].pType, TestPieceTypeBase.Instance);
        }
        [TestMethod]
        public void InvalidSpawnPieceOnSpace()
        {
            //Arrange
            string err;
            //Act
            Piece piece = board.SpawnPieceOnSpace("a9", TestPieceTypeBase.Instance, 1, out err);

            //Assert 
            Assert.AreEqual(err, "Second string char not parsable to int or outside range 1-8");
        }
        [TestMethod]
        public void InvalidSpawnPieceOnOccupiedSpace()
        {
            //Arrange
            string err;
            Piece piece1 = board.SpawnPieceOnSpace("a1", TestPieceTypeBase.Instance, 1, out _);
            //Act
            Piece piece2 = board.SpawnPieceOnSpace("a1", TestPieceTypeBase.Instance, 1, out err);

            //Assert
            Tuple<int, int> tuple = board.GetCoordFromString("a1", out _);
            Assert.AreEqual(board.grid[tuple.Item1,tuple.Item2], piece1);
            Assert.AreEqual(err, "Spawn invalid! Space at a1 is occupied!");
        }
        [TestMethod]
        public void GetCoordByStringA1()
        {
            Tuple<int, int> coord = board.GetCoordFromString("a1", out _);

            Assert.AreEqual(coord, Tuple.Create(0, 7));
        }
        [TestMethod]
        public void GetCoordByStringInvalidLength()
        {
            string err;

            Tuple<int, int> coord = board.GetCoordFromString("a1a", out err);

            Assert.AreEqual(err, "Chess coordinate has wrong length. Is 3 when it should be 2");
        }
        public void GetCoordByStringInvalidRank()
        {
            string err;

            Tuple<int, int> coord = board.GetCoordFromString("j1", out err);

            Assert.AreEqual(err, "Rank j not valid! Use letters a-h to denote rank!");
        }
        public void GetCoordByStringInvalidFile0()
        {
            string err;

            Tuple<int, int> coord = board.GetCoordFromString("a0", out err);

            Assert.AreEqual(err, "Second string char not parsable to int or outside range 1-8");
        }
        public void GetCoordByStringInvalidFile9()
        {
            string err;

            Tuple<int, int> coord = board.GetCoordFromString("a9", out err);

            Assert.AreEqual(err, "Second string char not parsable to int or outside range 1-8");
        }
        [TestMethod]
        public void TestPieceMovement()
        {
            //Arrange
            string err;
            Piece piece = board.SpawnPieceOnSpace("a1", TestPieceTypeBase.Instance, 1, out err);
            //Act
            board.MovePiece("a1", "a2", out err);
            //Assert
            Tuple<int, int> coord = board.GetCoordFromString("a2", out err);
            Assert.AreEqual(board.grid[coord.Item1, coord.Item2], piece);
            coord = board.GetCoordFromString("a1", out err);
            //Assert.IsNull(board.grid[coord.Item1, coord.Item2]);
        }
        [TestMethod] 
        public void TestInvalidPieceMovement()
        {
            //Arrange
            board.SpawnPieceOnSpace("a1", TestPieceTypeBase.Instance, 1, out _);
            //Act
            bool result = board.MovePiece("a1", "a1", out _);
            //Assert
            Assert.IsFalse(result);
        }
        /*
        [TestMethod]
        public void CorrectBoardSetupPawns()
        {

        }
        [TestMethod]
        public void CorrectBoardSetupRooks()
        {
        }
        [TestMethod]
        public void CorrectBoardSetupKnights()
        {
        }
        [TestMethod]
        public void CorrectBoardSetupBishops()
        {
        }
        [TestMethod]
        public void CorrectBoardSetupQueen()
        {
        }
        [TestMethod]
        public void CorrectBoardSetupKing()
        {
        }
        */
    }
    internal class TestPieceTypeBase : Singleton<TestPieceTypeBase>, IPieceType
    {
        public string Name => throw new NotImplementedException();

        public string DisplayChars => throw new NotImplementedException();        
        public string DisplayChar => throw new NotImplementedException();

        private static TestPieceTypeBase? instance;

        public static TestPieceTypeBase Instance
        {
            get
            {
                if (instance == null)
                    instance = new();
                return instance;
            }
        }

        public bool TryMove(string moveFrom, string moveTo, Board board, bool hasMoved, int player)
        {
            string err;
            return true;
        }
    }
}