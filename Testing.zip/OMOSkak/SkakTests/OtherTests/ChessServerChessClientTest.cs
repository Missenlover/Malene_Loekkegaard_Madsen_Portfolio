﻿using OMOClient;
using OMOSkakServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace SkakTests.OtherTests
{
    [TestClass]
    public class ChessServerChessClientTest
    {
        TcpListener listener;
        ChessServer chessServer;
        private Thread serverThread;

        ChessClient player1;
        ChessClient player2;

        private int port = 13000;
        private IPAddress localAddr = IPAddress.Parse("127.0.0.1");

        [TestInitialize]
        public void Initialize()
        {
            listener = new TcpListener(localAddr, port);
            chessServer = new ChessServer();

            player1 = new ChessClient();
            player1.testing = true;
            player2 = new ChessClient();
            player2.testing = true;
        }
        [TestMethod]
        public void PerformFirstGameMove()
        {
            //Arrange
            serverThread = new Thread(() =>
            {
                //Assert
                listener.Start();
                var client = listener.AcceptTcpClient();
                var client2 = listener.AcceptTcpClient();
                var stream = client.GetStream();
                byte[] buffer = new byte[256];

                //Act
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string message = Encoding.ASCII.GetString(buffer);
                chessServer.ParseMove(message);
                chessServer.SendBoardToClients();
                stream.Write(buffer, 0, bytesRead);
            });
            serverThread.Start();
            player1.ConnectClient();
            player2.ConnectClient();
            chessServer.StartGame();

            //Act
            player1.SimulateMessage("d2 to d4");
            Thread.Sleep(10);

            //Assert
            Tuple<int, int> coord = chessServer.gameboard.GetCoordFromString("d4", out _);
            Assert.IsNotNull(chessServer.gameboard.grid[coord.Item1, coord.Item2]);
            Assert.AreEqual(PawnPiece.Instance, chessServer.gameboard.grid[coord.Item1, coord.Item2].pType);
        }
    }
}
