﻿namespace OMOSkakServer
{
    public class Board
    {
        public Piece[,] grid = new Piece[8, 8];
        private int playerTurn { get; set; }
        /// <summary>
        /// Converts chess Rank/File notation into coordinate set usable by Grid.
        /// </summary>
        /// <param name="chessCoord">Standard chess coordinate notation in the format "ab" with a being rank (a-h), b being file (1-8)</param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public Tuple<int, int>? GetCoordFromString(string chessCoord, out string? errorMsg)
        {
            if (chessCoord.Length != 2)
            {
                errorMsg = $"Chess coordinate has wrong length. Is {chessCoord.Length} when it should be 2";
                Console.Error.WriteLine(errorMsg);
                return null;
            }
            int rank;
            switch (chessCoord.Substring(0, 1))
            {
                case ("a"):
                    rank = 0;
                    break;
                case ("b"):
                    rank = 1;
                    break;
                case ("c"):
                    rank = 2;
                    break;
                case ("d"):
                    rank = 3;
                    break;
                case ("e"):
                    rank = 4;
                    break;
                case ("f"):
                    rank = 5;
                    break;
                case ("g"):
                    rank = 6;
                    break;
                case ("h"):
                    rank = 7;
                    break;
                default:
                    errorMsg = $"Rank {chessCoord.Substring(0,1)} not valid! Use letters a-h to denote rank!";
                    Console.Error.WriteLine(errorMsg);
                    return null;
            }
            int file;
            if (!int.TryParse(chessCoord.Substring(1), out file) || file % 9 == 0)
            {
                errorMsg = "Second string char not parsable to int or outside range 1-8";
                Console.Error.WriteLine(errorMsg);
                return null;
            }
            file = Math.Abs(file - 8);
            errorMsg = "";
            return Tuple.Create(rank,file);
        }
        public Piece SpawnPieceOnSpace(string space, IPieceType pieceType, int player, out string err)
        {
            err = "";
            Tuple<int, int> coord = GetCoordFromString(space, out err);
            if(err.Length>0) { return null; }

            if (grid[coord.Item1,coord.Item2] != null)
            {
                err = $"Spawn invalid! Space at {space} is occupied!";
                Console.Error.WriteLine(err);
                return null;
            }
            return grid[coord.Item1,coord.Item2] = new Piece(pieceType, player);            
        }
        public string ParseMove(string move, int player)
        {
            return "a";
        }
        public bool MovePiece(string moveFrom, string moveTo, out string err)
        {
            err = "";
            if (moveFrom==moveTo)
            {
                Console.Error.WriteLine("Piece cannot perform move to own space");
                return false;
            }
            Tuple<int, int> coord1 = GetCoordFromString(moveFrom, out err);
            if(err.Length>0) { return false; }
            Piece piece = grid[coord1.Item1, coord1.Item2];

            if(!piece.TryMove(moveFrom, moveTo, this))
            {
                Console.Error.WriteLine("Illegal move!");
                return false;
            }


            Tuple<int, int> coord2 = GetCoordFromString(moveTo, out err);

            grid[coord1.Item1, coord1.Item2] = null;
            piece.hasMoved = true;
            grid[coord2.Item1, coord2.Item2] = piece;
            return true;
        }
        public bool BoardSetup()
        {
            SpawnPieceOnSpace("d2", PawnPiece.Instance, 1, out _);
            SpawnPieceOnSpace("c2", PawnPiece.Instance, 1, out _);

            return true;
        }

        public enum Ranks
        {
            a, b, c, d, e, f, g, h
        }
    }
}
