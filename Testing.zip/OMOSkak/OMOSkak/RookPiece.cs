﻿using OMOSkak;

namespace OMOSkakServer
{
    public class RookPiece : Singleton<RookPiece>, IPieceType
    {
        public string Name => "Rook";

        public string DisplayChars => "♖♜R";

        public bool TryMove(string moveFrom, string moveTo, Board board, bool hasMoved, int player)
        {
            string err;
            Tuple<int, int> coord = board.GetCoordFromString(moveFrom, out err);
            Tuple<int, int> coord2 = board.GetCoordFromString(moveTo, out err);
            //Check Ally occupied space
            if (board.grid[coord2.Item1,coord2.Item2] != null && board.grid[coord2.Item1, coord2.Item2].Player == player)
            {
                Console.Error.WriteLine("Cannot capture allied piece!");
                return false;
            }

            //Check vertical
            if (coord.Item1 == coord2.Item1)
            {
                if (coord.Item2 < coord2.Item2 - 1)
                {
                    for (int i = 0; i < coord2.Item2 - coord.Item2 - 1; i++)
                    {
                        if (board.grid[coord.Item1, coord.Item2 + i + 1] != null )
                        {
                            Console.Error.WriteLine("Obstructed path for move!");
                            return false;
                        }
                    }
                }
                if (coord.Item2 > coord2.Item2 + 1)
                {
                    for (int i = 0; i < coord.Item2 - coord2.Item2 - 1; i++)
                    {
                        if (board.grid[coord.Item1, coord.Item2 - i - 1] != null )
                        {
                            Console.Error.WriteLine("Obstructed path for move!");
                            return false;
                        }
                    }
                }
                return true;
            }
            //Check horizontal
            if (coord.Item2 == coord2.Item2)
            {
                if (coord.Item1 < coord2.Item1 - 1)
                {
                    for (int i = 0; i < coord2.Item1 - coord.Item1 - 1; i++)
                    {
                        if (board.grid[coord.Item1+i+1, coord.Item2] != null)
                        {
                            Console.Error.WriteLine("Obstructed path for move!");
                            return false;
                        }
                    }
                }
                if(coord.Item1 > coord2.Item1 + 1)
                {
                    for(int i = 0; i< coord.Item1 - coord2.Item1 - 1; i++)
                    {
                        if (board.grid[coord.Item1-i-1, coord.Item2] != null)
                        {
                            Console.Error.WriteLine("Obstructed path for move!");
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        }
    }
}
