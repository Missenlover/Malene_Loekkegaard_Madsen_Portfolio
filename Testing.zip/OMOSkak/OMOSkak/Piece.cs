﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace OMOSkakServer
{
    public class Piece
    {
        public Piece(IPieceType pType, int player)
        {
            this.pType = pType;
            this.player = player;
        }

        public IPieceType pType;
        public bool hasMoved = false;
        private int player;
        public int Player { get { return this.player; } }
        public bool TryMove(string moveFrom, string moveTo, Board board)
        {
            return pType.TryMove(moveFrom, moveTo, board, hasMoved, player);
        }
        public char GetDisplayChar()
        {
            char[] chars = pType.DisplayChars.ToCharArray();
            if (chars.Length < 1)
            {
                Console.Error.WriteLine($"No available chars in {pType.Name}");
                return '?';
            }
            if (chars.Length == 1) 
            { 
                return chars[0]; 
            }
            return pType.DisplayChars.ToCharArray()[player-1];
        }
        public char GetDisplayLetter()
        {
            char[] chars = pType.DisplayChars.ToCharArray();
            if (chars.Length<2)
            {
                Console.Error.WriteLine($"No available letter char in {pType.Name}");
                return '?';
            }
            return pType.DisplayChars.ToCharArray()[2];
        }
    }
}
