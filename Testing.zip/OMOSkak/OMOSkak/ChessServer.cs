﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMOSkakServer
{
    public class ChessServer
    {
        public Board gameboard;
        public void StartGame()
        {
            gameboard = new Board();
            gameboard.BoardSetup();

        }
        public void SendBoardToClients()
        {

        }
        public void ParseMove(string command)
        {
            string space1 = command.Substring(0,2);
            Console.WriteLine(space1);
            string space2 = command.Substring(6,2);
            Console.WriteLine(space2);
            if (!gameboard.MovePiece(space1, space2, out _))
            {
                Console.WriteLine("Illegal move!");
            }
        }
    }
}
