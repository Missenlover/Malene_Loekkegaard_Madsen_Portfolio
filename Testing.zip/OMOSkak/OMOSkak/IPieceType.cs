﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMOSkakServer
{
    public interface IPieceType
    {
        public static IPieceType Instance { get; }

        public string Name { get; }
        public string DisplayChars { get; }

        public abstract bool TryMove(string moveFrom, string moveTo, Board board, bool hasMoved, int player);
    }
}
