﻿using OMOSkak;

namespace OMOSkakServer
{
    public class PawnPiece : Singleton<PawnPiece>, IPieceType
    {
        public string Name => "Pawn";

        public string DisplayChars => "♙♟P";

        public bool TryMove(string moveFrom, string moveTo, Board board, bool hasMoved, int player)
        {
            string err;
            Tuple<int, int> coord = board.GetCoordFromString(moveFrom, out err);
            Tuple<int, int> coord2 = board.GetCoordFromString(moveTo, out err);
            //Check for p1 capture
            if (player == 1 && Math.Abs(coord.Item1 - coord2.Item1) == 1 && coord.Item2 == coord2.Item2 + 1)
            {
                if (board.grid[coord2.Item1, coord2.Item2] == null)
                {
                    return false;
                }
                if (board.grid[coord2.Item1, coord2.Item2].Player != player)
                {
                    return true;
                }
                return false;
            }
            //Check for p2 capture
            if (player == 2 && Math.Abs(coord.Item1 - coord2.Item1) == 1 && coord.Item2 == coord2.Item2 - 1)
            {
                if (board.grid[coord2.Item1, coord2.Item2] == null)
                {
                    return false;
                }
                if (board.grid[coord2.Item1, coord2.Item2].Player != player)
                {
                    return true;
                }
                return false;
            }
            //Check for allied piece or enemy piece in front
            if (board.grid[coord2.Item1, coord2.Item2] != null)
            {
                return false;
            }
            //Check for 1 forward p1
            if (player == 1 && coord.Item1 == coord2.Item1 && coord.Item2 == coord2.Item2 + 1)
            {
                return true;
            }
            //Check for 1 forward p2
            if (player == 2 && coord.Item1 == coord2.Item1 && coord.Item2 == coord2.Item2 - 1)
            {
                return true;
            }
            //Check for P1 2 forward
            if (player == 1 && coord.Item1 == coord2.Item1 && coord.Item2 == coord2.Item2 + 2)
            {
                if (hasMoved)
                {
                    return false;
                }
                if (board.grid[coord.Item1, coord.Item2 + 1] != null)
                {
                    return false;
                }
                return true;
            }
            //Check for P2 2 forward
            if (player == 2 && coord.Item1 == coord2.Item1 && coord.Item2 == coord2.Item2 - 2)
            {
                if (hasMoved)
                {
                    return false;
                }
                if (board.grid[coord.Item1, coord.Item2 - 1] != null)
                {
                    return false;
                }
                return true;
            }
            
            return false;
        }
    }
}
