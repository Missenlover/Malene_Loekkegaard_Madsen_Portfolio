﻿using OMOSkakServer;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace OMOSkak
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TcpListener server = null;

            try
            {
                int port = 13000;
                IPAddress localAddr = IPAddress.Parse("127.0.0.1");

                server = new TcpListener(localAddr, port);
                server.Start();

                while (true)
                {
                    TcpClient client = server.AcceptTcpClient();
                    Thread clientThread = new Thread(() => HandleClient(client));
                    clientThread.Start();
                }
            }
            catch (SocketException e)
            {

                Console.WriteLine($"Socketexception: {e}");
            }
            finally
            {
                server.Stop();
            }
        }
        static void HandleClient(TcpClient client)
        {
            byte[] bytes = new byte[256];
            string data = null;

            NetworkStream stream = client.GetStream();

            int i;

            while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
            {
                data = Encoding.ASCII.GetString(bytes, 0, i);

                byte[] msg = Encoding.ASCII.GetBytes(data);

                stream.Write(msg, 0, msg.Length);

            }
            client.Close();
        }
    }
}
