﻿using OMOSkak;

namespace OMOSkakServer
{
    public class BishopPiece : Singleton<BishopPiece>, IPieceType
    {
        public string Name => "Bishop";

        public string DisplayChars => "♗♝B";


        public bool TryMove(string moveFrom, string moveTo, Board board, bool hasMoved, int player)
        {
            Tuple<int, int> coord = board.GetCoordFromString(moveFrom, out _);
            Tuple<int, int> coord2 = board.GetCoordFromString(moveTo, out _);

            int horizDiff = coord.Item1 - coord2.Item1;
            int vertDiff = coord.Item2 - coord2.Item2;
            if (Math.Abs(horizDiff)==Math.Abs(vertDiff))
            {
                int horizDir = horizDiff/Math.Abs(horizDiff);
                int vertDir = vertDiff/Math.Abs(vertDiff);
                for (int i = 1; i < Math.Abs(vertDiff); i++)
                {
                    
                }
                return true;
            }
            return false;
        }
    }
}
