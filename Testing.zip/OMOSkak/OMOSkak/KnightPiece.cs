﻿using OMOSkak;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMOSkakServer
{
    public class KnightPiece : Singleton<KnightPiece>, IPieceType
    {
        public string Name => "Knight";

        public string DisplayChars => "♘♞N";

        public bool TryMove(string moveFrom, string moveTo, Board board, bool hasMoved, int player)
        {
            Tuple<int, int> coord1 = board.GetCoordFromString(moveFrom, out _);
            Tuple<int, int> coord2 = board.GetCoordFromString(moveTo, out _);
            if (board.grid[coord2.Item1,coord2.Item2] != null)
            {
                if (board.grid[coord2.Item1, coord2.Item2].Player==player)
                {
                    return false;
                }
            }
            if (Math.Abs(coord1.Item1-coord2.Item1)==1 && Math.Abs(coord1.Item2-coord2.Item2)==2)
            {
                return true;
            }
            if (Math.Abs(coord1.Item1 - coord2.Item1) == 2 && Math.Abs(coord1.Item2 - coord2.Item2) == 1)
            {
                return true;
            }

            return false;
        }
    }
}
