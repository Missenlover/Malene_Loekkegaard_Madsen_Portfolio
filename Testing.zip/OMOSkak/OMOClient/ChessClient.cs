﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace OMOClient
{
    public class ChessClient
    {
        public TcpClient client;
        public bool testing = false;
        public NetworkStream stream;
        public void ConnectClient()
        {
			try
			{
                int port = 13000;
                client = new TcpClient();

                client.Connect("127.0.0.1", port);

                stream = client.GetStream();

                //Thread readThread = new Thread(() => ReadMessages(stream));
                //readThread.Start();

                while (!testing)
                {
                    string message = Console.ReadLine();
                    if (string.IsNullOrEmpty(message)) continue;

                    byte[] data = Encoding.ASCII.GetBytes(message);
                    stream.Write(data, 0, data.Length);
                }
			}
			catch (ArgumentNullException e)
			{
				Console.WriteLine($"ArgumentNullException: {e}");
			}
            catch (SocketException e)
            {
                Console.WriteLine($"SocketException: {e}");
            }
        }
        static void ReadMessages(NetworkStream stream)
        {
            byte[] bytes = new byte[256];
            string data = null;

            int i;
            while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
            {
                data = Encoding.ASCII.GetString(bytes, 0, i);

                Console.WriteLine(data);
            }
        }
        public void SimulateMessage(string message)
        {
            byte[] data = Encoding.ASCII.GetBytes(message);
            stream.Write(data, 0, data.Length);
        }
    }
}
