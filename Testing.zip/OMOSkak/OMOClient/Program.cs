﻿// See https://aka.ms/new-console-template for more information
using OMOClient;

Console.WriteLine("Hello, World!");
ChessClient client = new ChessClient();

client.ConnectClient();
